//
//  LYLoginViewController.h
//  ITSNS
//
//  Created by Ivan on 16/1/10.
//  Copyright © 2016年 Ivan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LYLoginViewController : UIViewController

@end
