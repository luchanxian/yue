//
//  TRSendingViewController.h
//  ITSNS
//
//  Created by tarena on 16/8/24.
//  Copyright © 2016年 Ivan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TRSendingViewController : UIViewController
@property (nonatomic, strong)NSString *type;
@end
