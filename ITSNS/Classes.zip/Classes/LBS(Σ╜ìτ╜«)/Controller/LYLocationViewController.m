//
//  LYLocationViewController.m
//  ITSNS
//
//  Created by Ivan on 16/1/9.
//  Copyright © 2016年 Ivan. All rights reserved.
//
#import "TRPointAnnotation.h"
#import "TRAnnotationView.h"
#import "TRITObject.h"
#import "LYLocationViewController.h"
#import <BaiduMapAPI_Base/BMKBaseComponent.h>//引入base相关所有的头文件
#import <BaiduMapAPI_Map/BMKMapComponent.h>//引入地图功能所有的头文件
@interface LYLocationViewController ()<BMKMapViewDelegate>
@property (nonatomic, strong)BMKMapView* mapView;
@end

@implementation LYLocationViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    BMKMapView* mapView = [[BMKMapView alloc]initWithFrame:[UIScreen mainScreen].bounds];
    mapView.delegate = self;
    [self.view addSubview:mapView];
    self.mapView = mapView;
}


- (void)mapView:(BMKMapView *)mapView regionDidChangeAnimated:(BOOL)animated{
    

    [self.mapView removeAnnotations:self.mapView.annotations];
    
    
    //发出请求 获取某个位置周边的问题消息或项目
    BmobQuery *query = [BmobQuery queryWithClassName:@"ITObject"];
    //得到地图中心点位置
    BmobGeoPoint *point = [[BmobGeoPoint alloc]initWithLongitude:mapView.centerCoordinate.longitude WithLatitude:mapView.centerCoordinate.latitude];
    [query includeKey:@"user"];
    [query whereKey:@"location" nearGeoPoint:point withinKilometers:10];
    
    [query findObjectsInBackgroundWithBlock:^(NSArray *array, NSError *error) {
       
        for (BmobObject *bObj in array) {
            
            TRITObject *itObj = [[TRITObject alloc]initWithBmobObject:bObj];
            //判断是否有位置
            if (itObj.location) {
                
               TRPointAnnotation *pointAnnotation = [[TRPointAnnotation alloc]init];
                
                pointAnnotation.userInfo = itObj;
                
                CLLocationCoordinate2D coor;
                coor.latitude = itObj.location.latitude;
                coor.longitude = itObj.location.longitude;
                pointAnnotation.coordinate = coor;
                pointAnnotation.title = [itObj.user objectForKey:@"nick"];
                pointAnnotation.subtitle = itObj.title;
                
                [self.mapView addAnnotation:pointAnnotation];
            }
            
            
        }
        
        
        
    }];
    
}

-(BMKAnnotationView *)mapView:(BMKMapView *)mapView viewForAnnotation:(id<BMKAnnotation>)annotation{

    TRAnnotationView *annView = (TRAnnotationView *)[mapView dequeueReusableAnnotationViewWithIdentifier:@"ann"];
    if (!annView) {
        annView = [[TRAnnotationView alloc]initWithAnnotation:annotation reuseIdentifier:@"ann"];
    }
    
    TRPointAnnotation *ann = (TRPointAnnotation *)annotation;
    annView.itObj = ann.userInfo;
    
    
    
    
    return annView;
    
    
    
}

@end
