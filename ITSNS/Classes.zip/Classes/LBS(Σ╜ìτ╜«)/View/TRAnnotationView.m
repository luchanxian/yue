//
//  TRAnnotationView.m
//  ITSNS
//
//  Created by tarena on 16/8/31.
//  Copyright © 2016年 Ivan. All rights reserved.
//

#import "TRAnnotationView.h"

@implementation TRAnnotationView

-(id)initWithAnnotation:(id<BMKAnnotation>)annotation reuseIdentifier:(NSString *)reuseIdentifier{
    
    self = [super initWithAnnotation:annotation reuseIdentifier:reuseIdentifier];
    if (self) {
        
        UIImageView *bgIV = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 160, 70)];
        bgIV.image = [UIImage imageNamed:@"nearby_map_content"];
        [self addSubview:bgIV];
        
        
        self.headIV = [[UIImageView alloc]initWithFrame:CGRectMake(10, 10, 50, 50)];
        [self addSubview:self.headIV];
        
        self.nickLabel = [[UILabel alloc]initWithFrame:CGRectMake(70, 10, 80, 20)];
        [self addSubview:self.nickLabel];
        
        self.titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(70, 40, 80, 20)];
        [self addSubview:self.titleLabel];
        self.titleLabel.textColor = self.nickLabel.textColor = [UIColor whiteColor];
    }
    
    return self;
}

-(void)setItObj:(TRITObject *)itObj{
    _itObj = itObj;
    self.titleLabel.text = itObj.title;
    self.nickLabel.text = [itObj.user objectForKey:@"nick"];
    [self.headIV sd_setImageWithURL:[NSURL URLWithString:[itObj.user objectForKey:@"headPath"]] placeholderImage:[UIImage imageNamed:@"loadingImage"]];
    
    
    
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
