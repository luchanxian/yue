//
//  TRAnnotation.m
//  ITSNS
//
//  Created by tarena on 16/8/31.
//  Copyright © 2016年 Ivan. All rights reserved.
//

#import "TRPointAnnotation.h"

@implementation TRPointAnnotation

@end
