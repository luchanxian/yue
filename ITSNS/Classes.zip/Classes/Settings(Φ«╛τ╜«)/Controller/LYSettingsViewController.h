//
//  LYSettingsViewController.h
//  蓝懿微博
//
//  Created by Ivan on 15/12/24.
//  Copyright © 2015年 Ivan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LYSettingsViewController : UIViewController

@end
