//
//  TRImagesView.h
//  ITSNS
//
//  Created by tarena on 16/8/26.
//  Copyright © 2016年 Ivan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TRImagesView : UIView
@property (nonatomic, strong)NSArray *imagePaths;
@end
